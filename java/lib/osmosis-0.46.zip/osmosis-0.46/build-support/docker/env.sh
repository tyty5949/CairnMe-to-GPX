export gradleUserDir="${HOME}/.gradle"
export userId=$(id -u)
export groupId=$(id -g)
export projectDir="$( cd "${scriptDir}"/../.. && pwd )"
